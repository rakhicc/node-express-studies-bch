'use strict';
const http=require('http');

const {port,host}=require('./config.json');

const person=require('./person.json');

const server=http.createServer((req,res)=>{
res.writeHead(200,{
    'Content-Type':'text/html;charset=utf-8'
});

res.end(createHtml(person));
});
server.listen(port,host,()=>console.log(
    `server ${port}:${host} is listening`
))

function createHtml(person){
return `
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Person</title>
</head>
<body>
   <h1>Person data</h1> 
   <h2>${person.firstName} ${person.lastName}</h2>
</body>
</html>`
}