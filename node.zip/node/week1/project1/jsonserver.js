'use strict';

const person={
    firstname:"rakhi",
    lastname:"chandran"
}

const http = require('http');



const port=3000;

const host='localhost';



const server = http.createServer((request,response)=>{



    response.writeHead(200, {

        'Content-Type':'application/json',
        'Access-Control-Allow-Origin':'*'

    });

    // resoponse.write('<h1>Hello world</h1>');

    // response.end();

    response.end(JSON.stringify(person));

});

server.listen(port,host, 

    ()=>console.log(`Server ${host}:${port} is listening`));