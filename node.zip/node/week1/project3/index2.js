"use strict";

const http = require("http");
const path = require("path");
const fs = require("fs").promises;

const { port, host } = require("./config.json");
const homePath = path.join(__dirname, "home.html");
const pageBpath = path.join(__dirname, "pageb.html");
console.log(__dirname);
console.log(homePath);
const server = http.createServer((req, res) => {
  const { pathname } = new URL(`http://${host}:${port}${req.url}`);
  const route = decodeURIComponent(pathname);
  console.log(route);
  if (route === "/") {
    console.log("reached /");
    sendFile(res, homePath);
  } else if (route === "/pageb") {
    console.log("reached pageb");
    sendFile(res, pageBpath);
  } else if (route.startsWith("/styles/")) {
    console.log("reached styles");
    sendFile(res, path.join(__dirname, route), "text/css");
  }
});
server.listen(port, host, () =>
  console.log("server ${host}:${port} is listening")
);

async function sendFile(res, filePath, contentType = "text/html") {
  try {
    console.log("called");
    const data = await fs.readFile(filePath, "utf-8");
    res.writeHead(200, {
      "Content-Type": contentType,
      "Content-Length": Buffer.byteLength(data, "utf8"),
    });
    res.end(data);
  } catch (err) {
    res.statusCode = 404;
    res.end(`Èrror:${err.message}`);
  }
}
