'use strict';
const http=require('http');
const { URL } = require('url');
const {port,host}=require('./config.json');


const server=http.createServer((req,res)=>{
    const {searchParams}=new URL(`http://${host}:${port}${req.url}`);

res.writeHead(200,{
    'Content-Type':'text/html;charset-utf8'
});
    if(searchParams.has('name')){
    const name=searchParams.get('name');
    res.end(`<h1>Hi ${name}</h1>`);
} else {
    res.end(`<h1>Hi anonymous</h1>`);
}
});
server.listen(port,host,()=>console.log(`${host}:${port} server is listening`));

//http://localhost:3000/?name=rakhi
//http://localhost:3000/?age=20&name=rakhi will also work
//http://localhost:3000/?name wil show Hi only since name is empty
