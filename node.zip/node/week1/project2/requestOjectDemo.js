'use strict';
const http=require('http');
const { URL } = require('url');
const port=process.env.PORT || 3000;
const host=process.env.HOST || 'localhost';
console.log(process.env.host);
console.log(process.env.HOST);
console.log(Object.keys(process.env));
const server=http.createServer((req,res)=>{
    //console.log(Object.keys(req));
    //console.log(Object.keys(req.headers));
    const {
        pathname,
        search,
        searchParams
    }=new URL(`http://${host}:${port}${req.url}`);
    console.log(new URL(`http://${host}:${port}${req.url}`))
const route=decodeURIComponent(pathname);// this s used to decode uri if it contains any characters rather than alphabets
console.log(route);
res.writeHead(200,{
    'Content-Type':'text/html; charset=utf-8'
});
let message='';
if(route.startsWith('/abc')){
    message='abc';
} else if(route==='/xyz'){
    message='xyz';
} else {
    message='something else';
}
res.end(`<h1>${message}</h1>`);
});



    server.listen(port,host,
        ()=>console.log('server ${host}:${port} is listening'));