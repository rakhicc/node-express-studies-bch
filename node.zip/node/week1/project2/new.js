'use strict';
const http=require('http');
const { URL } = require('url');
const port=process.env.PORT || 3000;
const host=process.env.HOST || 'localhost';
console.log(process.env.host);
console.log(process.env.HOST);
console.log(Object.keys(process.env));
const server=http.createServer((req,res)=>{
    //console.log(Object.keys(req));
    //console.log(Object.keys(req.headers));
    const {
        pathname,
        search,
        searchParams
    }=new URL(`http://${host}:${port}${req.url}`);
    console.log(new URL(`http://${host}:${port}${req.url}`))
const route=decodeURIComponent(pathname);// this s used to decode uri if it contains any characters rather than alphabets
console.log(route);
res.writeHead(200,{
    'Content-Type':'text/html; charset=utf-8'
});
res.write(`<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Request Info</title>
</head>
<body>
<h1>Request info</h1>
<h2>headers:</h2>
<pre>${JSON.stringify(req.headers,null,4)}</pre>
<h2>host:${req.headers.host}</h2>
<h2>agent:${req.headers['user-agent']}</h2>
<h2>method:${req.method}</h2>
<h2>pathname:${pathname}</h2>
<h2>search:${search}</h2>
<h2>searchparams:${searchParams}</h2>
<h2>url:${req.url}</h2>
<h2>decoded pathname:${route}</h2>
</body>
</html>`);
res.end();
});



    server.listen(port,host,
        ()=>console.log('server ${host}:${port} is listening'));