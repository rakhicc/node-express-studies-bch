const persons = require("./persons.json");

function search(key, value) {
  console.log("reached search function");
  if (key && value) {
    const result = [];

    for (let person of persons) {
      if (person[key] == value) {
        result.push(person);
      }
    }

    return result;
  } else {
    return persons;
  }
}

module.exports = { search };

/* you can do other WebAssembly
if(person[key]===value){
    add to array
} */

/* console.log(search());
console.log(search("firstname", "Matt"));
console.log(search("lastname", "River"));
console.log(search("age", 30));
console.log(search("age", 50)); */
