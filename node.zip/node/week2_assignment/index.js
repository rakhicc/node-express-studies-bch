"use strict";
const http = require("http");
const { port, host } = require("./config.json");
const { search } = require("./personStorage");

const server = http.createServer((req, res) => {
  const { pathname, searchParams } = new URL(
    `http://${host}:${port}${req.url}`
  );

  const route = decodeURIComponent(pathname);
  let result = [];
  if (route === "/persons") {
    result = search();
  } else if (route === "/persons/lastname" && searchParams.has("value")) {
    result = search("lastname", searchParams.get("value"));
  } else if (route === "/persons/firstname" && searchParams.has("value")) {
    result = search("firstname", searchParams.get("value"));
  } else if (route === "/persons/age" && searchParams.has("value")) {
    result = search("age", searchParams.get("value"));
  } else {
    result = { message: "Resource not found" };
  }
  res.writeHead(200, {
    "Content-Type": "text/html;charset=utf-8",
  });
  res.end(createHtml(result));
});
server.listen(port, host, () =>
  console.log(`server${host}:${port} is listening`)
);
function createHtml(resultArray) {
  let htmlString = createheader();
  if (resultArray.length === 0) {
    htmlString += `<h2>No persons found </h2>`;
  } else if (resultArray.message) {
    htmlString += `<h2>${resultArray.message}  </h2>`;
  } else {
    htmlString += createtable(resultArray);
  }
  htmlString += `</body></html>`;
  return htmlString;
}
function createtable(resultArray) {
  let htmlContent = `<table>
    <thead>
    <tr><th>First Name</th><th>Last name</th><th>Age</th></tr>
    </thead>
    <tbody>`;
  for (let person of resultArray) {
    htmlContent += `<tr><td>${person.firstname} </td>
        <td>${person.lastname} </td>
        <td>${person.age} </td>
        </tr>`;
  }
  htmlContent += `</tbody></table>`;
  return htmlContent;
}

function createheader() {
  return `<!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Persons</title>
    </head>
    <body>
      <h1>Search result</h1>`;
}
