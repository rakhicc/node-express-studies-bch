# Person api

## persons.json

```json
[
  { "firstname": "Matt", "lastname": "River", "age": 30 },
  { "firstname": "Rakhi", "lastname": "Chandran", "age": 31 },
  { "firstname": "Mary", "lastname": "Smith", "age": 50 }
]
```

## DataLayer for person

## function ** search(key,value)**

Function returns person objects in an array.search criterion is passed to function as parameters.
if parameters are missing all persons are returned.if no person matches the criteria an empty array is returned.

### examples

```js
search();
search("firstname");
```

returns

```json
[
  { "firstname": "Matt", "lastname": "River", "age": 30 },
  { "firstname": "Rakhi", "lastname": "Chandran", "age": 31 },
  { "firstname": "Mary", "lastname": "Smith", "age": 50 }
]
```

```js
search("firstname", "Matt");
```

returns

```json
[
  { "firstname": "Matt", "lastname": "River", "age": 30 } }
]
```

## Usage

### search all persons

```
http://localhost:3000/persons
```

###search by lastname
http://localhost:3000/persons/lastname?value=River

###search by firstname
http://localhost:3000/persons/firstname?value=Matt
###search by age
http://localhost:3000/persons/age?value=30

server sends a web page to the browser,use table element to show the data.
