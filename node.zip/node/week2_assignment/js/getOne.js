"use strict";
(function () {
  let resultset;
  let messagearea;
  let lastnamefield;
  let key;
  let valueInput;
  document.addEventListener("DOMContentLoaded", init);
  function init() {
    messagearea = document.getElementById("messageArea");
    resultset = document.getElementById("resultset");

    key = document.getElementById("key");
    console.log(key);
    valueInput = document.getElementById("value");
    console.log(valueInput);
    document.getElementById("submit").addEventListener("click", submit);
  }
  async function submit() {
    try {
      resultset.innerHTML = "";
      messagearea.textContent = "";

      const keyvalue = key.value;
      const valueField = valueInput.value;
      const data = await fetch(`/persons/${keyvalue}?value=${valueField}`);
      //default method is get
      //const data = await fetch(`/persons/lastname?value=${lastname}`);
      const persons = await data.json();
      console.log(persons);
      console.log(persons.message);
      if (persons.message) {
        messagearea.textContent = persons.message;
        console.log(persons.message);
      } else {
        for (let person of persons) {
          const tr = document.createElement("tr");
          tr.appendChild(createCell(person.firstname));
          tr.appendChild(createCell(person.lastname));
          tr.appendChild(createCell(person.age));
          resultset.appendChild(tr);
        }
      }
    } catch (err) {
      messagearea.textContent = err.message;
    }
  } // end of init here

  function createCell(text) {
    const td = document.createElement("td");
    td.textContent = text;
    return td;
  }
})();
