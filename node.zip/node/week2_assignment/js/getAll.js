"use strict";
(function () {
  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    try {
      const data = await fetch("/persons"); //default method is get
      const persons = await data.json();
      const resultset = document.getElementById("resultset");
      for (let person of persons) {
        const tr = document.createElement("tr");
        tr.appendChild(createCell(person.firstname));
        tr.appendChild(createCell(person.lastname));
        tr.appendChild(createCell(person.age));
        resultset.appendChild(tr);
      }
    } catch (err) {
      document.getElementById("messageArea").textContent = err.message;
    }
  } // end of init here

  function createCell(text) {
    const td = document.createElement("td");
    td.textContent = text;
    return td;
  }
})();
