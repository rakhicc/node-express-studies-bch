"use strict";
const { urlencoded } = require("express");
const express = require("express");
const path = require("path");
const app = express();

const { port, host } = require("./config.json");
const menupath = path.join(__dirname, "menu.html");
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "pagetemplates"));

app.use(express.urlencoded({ extended: false }));
app.get("/", (req, res) => res.sendFile(menupath));
app.get("/personform", (req, res) =>
  res.render("form", {
    title: "person data",
    header: "Insert data",
    action: "/handleperson",
    passType: "text",
    name: "Last name",
  })
);
app.get("/loginform", (req, res) =>
  res.render("loginform", {
    title: "Person data",
    header: "insert login credential",
    action: "/login",
    passType: "password",
    name: "Password",
  })
);
app.post("/handleperson", (req, res) =>
  res.render("result", {
    title: "person data result",
    header: "Person Info",
    person: req.body,
    name: "Last name",
  })
);
app.post("/login", (req, res) =>
  res.render("result", {
    title: "Login data",
    header: "Your data",
    person: req.body,
    name: "Password",
  })
);
app.listen(port, host, () => console.log(`${host}:${port} listening..`));
