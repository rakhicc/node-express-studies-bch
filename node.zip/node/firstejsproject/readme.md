## npm install express and ejs

## you can use both at same time

##

```shell
npm install express ejs
```

## seperately

```shell
npm install express
npm install ejs
```
