const cars = require("./cars.json");

function getAllCars() {
  return cars;
}

function getWithLicense(licence) {
  for (let car of cars) {
    console.log(car.licence);
    if (car.licence === licence) {
      return [car];
    }
  }
  return [];
}

function getWithModel(model) {
  const found = [];
  for (let car of cars) {
    if (car.model === model) {
      found.push(car);
    }
  }
  return found;
}

module.exports = { getAllCars, getWithLicense, getWithModel };
