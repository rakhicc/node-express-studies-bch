"use strict";
const http = require("http");
const path = require("path");
const { sendFile } = require("./filehandler");
const { port, host } = require("./config.json");
const formpath = path.join(__dirname, "index.html");
const server = http.createServer(async (req, res) => {
  const method = req.method.toUpperCase();
  if (method === "GET") {
    sendFile(res, formpath);
  } else if (method === "POST") {
    const formData = await handlePostData(req);
    res.writeHead(200, {
      "Content-Type": "application/json",
    });
    res.end(JSON.stringify(formData));
  }
});

server.listen(port, host, () => console.log(`serving ${host}:${port}`));

function handlePostData(req) {
  return new Promise((resolve, reject) => {
    if (req.headers["content-type"] !== "application/x-www-form-urlencoded") {
      reject("Wrong Content-type");
    } else {
      const databuffer = [];
      req.on("data", (messageFragment) => databuffer.push(messageFragment));
      req.on("end", () => {
        const params = new URLSearchParams(
          Buffer.concat(databuffer).toString()
        );
        const jsonResult = {};
        for (const [name, value] of params) {
          console.log(name, value);
          jsonResult[name] = value;
        }
        return resolve(jsonResult);
      });
      req.on("error", () => reject("error during data transmission"));
    }
  });
}
