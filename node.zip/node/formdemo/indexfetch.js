"use strict";
const http = require("http");
const path = require("path");
const { sendFile } = require("./filehandler");
const { port, host } = require("./config.json");
const formpath = path.join(__dirname, "jsonform.html");
const server = http.createServer(async (req, res) => {
  const method = req.method.toUpperCase();
  console.log(method);
  if (method === "GET") {
    sendFile(res, formpath);
  } else if (method === "POST") {
    const formData = await handlePostData(req);
    console.log("request", req);
    res.writeHead(200, {
      "Content-Type": "application/json",
    });
    res.end(JSON.stringify(formData));
  }
});

server.listen(port, host, () => console.log(`serving ${host}:${port}`));

function handlePostData(req) {
  return new Promise((resolve, reject) => {
    if (req.headers["content-type"] !== "application/json") {
      reject("Wrong Content-type");
    } else {
      const databuffer = [];
      req.on("data", (messageFragment) => databuffer.push(messageFragment));
      req.on("end", () => {
        const data = Buffer.concat(databuffer).toString();
        console.log("handlepostdata", JSON.parse(data));
        return resolve(JSON.parse(data));
      });
      req.on("error", () => reject("error during data transmission"));
    }
  });
}
