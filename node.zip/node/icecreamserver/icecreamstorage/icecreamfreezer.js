"use strict";
const path = require("path");
const fs = require("fs").promises;
const jsonPath = require("./icecream.json");
console.log(jsonPath);
const read = async (filePath) => {
  try {
    console.log(filePath);
    const data = await fs.readFile(filePath, "utf8");
    console.log("data", data);
    return JSON.parse(data);
  } catch (err) {
    throw new Error("not valid json");
  }
};
const getAllFlavours = async () => {
  try {
    const icecreams = await read(jsonPath);
    console.log("icecreams", icecreams);
    return Object.keys(icecreams);
  } catch (err) {
    console.log(err.message);
    return [];
  }
};
const hasFlavor = async (flavor) => {
  try {
    const icecreams = await read(jsonPath);
    return Object.keys(icecreams).includes(flavor);
  } catch (err) {
    return false;
  }
};
const getIcecream = async (flavor) => {
  try {
    const icecreams = await read(jsonPath);
    return icecreams[flavor] || null;
  } catch (err) {
    return null;
  }
};
getAllFlavours().then(console.log).catch(console.log);
hasFlavor("raspberry").then(console.log).catch(console.log);
getIcecream("raspberry").then(console.log).catch(console.log);
module.exports = { getAllFlavours, hasFlavor, getIcecream };
