# Express app

# create folder for application

## create package.json file for the app

- manually or using npm with npm init,
- if manually put atleast name and version

```shell
npm init -y
```

or

```shell
   npm init
```

and answer the questions

you can edit the package.json file later with editor

## install all libraries

```shell
npm install express
```

Installed libraries will be in the node_modules folder

Command

```shell
npm install
```

install all dependencies that are in the package.json

## check licenses

```shell
npx license-checker --summary
```

for short list, and

```shell
npx license-checker
```

for longer list(verbose output)

## to check vulnerabilities

```shell
npm audit
```
