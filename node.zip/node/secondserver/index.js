"use strict";
const http = require("http");
const express = require("express");
const app = express();
const host = "localhost";
const port = 3000;

const server = http.createServer(app);
app.get("/", (req, res) => res.send("Hello World"));
server.listen(port, host, () => console.log(`serving ${host}:${port}`));
