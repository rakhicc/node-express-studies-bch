"use strict";
const fs = require("fs").promises;
const path = require("path");
const Mimetypes = require(path.join(__dirname, "mimetypes.json"));
console.log(Mimetypes);
const read = (filePath) => {
  const extension = path.extname(filePath).toLowerCase();
  console.log("extension", extension);
  const mime = Mimetypes[extension] || {
    type: "application/octet-stream",
    encoding: "binary",
  };

  return fs
    .readFile(filePath, mime.encoding)
    .then((filedata) => ({
      filedata,
      mime,
    }))
    .catch((err) => err);
};
read("./mimetypes.json").then(console.log).catch(console.log);
read("./handler.js").then(console.log).catch(console.log);
const send = (res, resource) => {
  res.writeHead(200, {
    "Content-Type": resource.mime.type,
    "Content-Length": Buffer.byteLength(
      resource.filedata,
      resource.mime.encoding
    ),
  });
  res.end(resource.filedata, resource.mime.encoding);
};
const sendJson = (res, jsonResource, statuscode = 200) => {
  const jsonData = JSON.stringify(jsonResource);
  res.writeHead(statuscode, {
    "Content-Type": "application/json",
  });
  res.end(jsonData);
};
const isIn = (route, ...routes) => {
  for (let start of routes) {
    console.log("start", start);
    console.log("route", route);
    if (route.startsWith(start)) return true;
  }
  return false;
};

module.exports = { read, send, sendJson, isIn };
