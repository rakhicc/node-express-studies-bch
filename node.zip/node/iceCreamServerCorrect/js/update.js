"use strict";
(function () {
  let icecreamlist;
  let resultarea;
  document.addEventListener("DOMContentLoaded", init);
  async function init() {
    icecreamlist = document.getElementById("icecreamlist");
    resultarea = document.getElementById("resultarea");
    try {
      const data = await fetch("/icecreams");
      const flavors = await data.json();
      console.log(flavors);
      popuateIcecreamList(flavors);
    } catch (err) {
      showErrorMessage(err.message);
    }
  }

  function popuateIcecreamList(queryresult) {
    if (!queryresult || queryresult.message) {
      console.log("!queryresult");
      showErrorMessage("sorry something went wrong ");
    } else {
      for (let flavor of queryresult) {
        const option = document.createElement("option");
        option.value = flavor;
        option.textContent = flavor;
        icecreamlist.appendChild(option);
      }
      icecreamlist.addEventListener("change", choose);
      icecreamlist.value = "";
    }
  }

  async function choose() {
    console.log("!choose");
    const icecreamFlavor = icecreamlist.value;
    if (icecreamFlavor.length > 0) {
      console.log("icecreamFlavor.length > 0");
      try {
        const data = await fetch(`/icecreams/${icecreamFlavor}`);
        const result = await data.json();
        console.log("updateresult");
        updateResult(result);
      } catch (err) {
        showErrorMessage(err.message);
      }
    } else {
      cleraResultarea();
    }
  }

  function cleraResultarea() {
    resultarea.innerHTML = "";
  }

  function updateResult(data) {
    console.log("updateresult reached");
    if (!data) {
      showErrorMessage("programming error,sorry!");
    } else if (data.message) {
      showErrorMessage(data.message);
    } else if (data.name && data.name.length === 0) {
      cleraResultarea();
    } else {
      console.log("forming htmlstring");
      let htmlString = `
        <div>
        <p id="name">${data.name}</p>
        <p id="price">${data.price} €</p>
        </div>`;
      if (data.image && data.image.length > 0) {
        htmlString += `<img src="/images/${data.image}" />`;
      }
      console.log("forming htmlstring", htmlString);
      resultarea.innerHTML = htmlString;
    }
  }
  function showErrorMessage(message) {
    resultarea.innerHTML = `
    <div class="error">
        <h2>Error</h2>
        <p>${message}</p>
    </div>`;
  }
})();
